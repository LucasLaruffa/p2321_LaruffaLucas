package persistence;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;
import models.ViajeTemporal;



public interface PersistenciaViajes<T> {
    void guardarEnCSV( String path);
    
    
     void cargarDesdeCSV(String path, Function<? super T, ? extends T> transformacion);
    
     void guardarEnArchivo(String path) throws IOException;
     
     void cargarDesdeArchivo(String path) throws ClassNotFoundException;
    

    

    }
    


