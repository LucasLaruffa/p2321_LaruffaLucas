

package parcial2321;

import java.io.IOException;
import models.DestinoTemporal;
import models.LibroDeViajes;
import models.ViajeTemporal;


public class Parcial2321 {

    public static void main(String[] args) throws IOException, ClassNotFoundException {
        try{
LibroDeViajes<ViajeTemporal> libro = new LibroDeViajes<>();
libro.agregar(new ViajeTemporal(1, "Salvar a George McFly", "Marty McFly",
DestinoTemporal.HILL_VALLEY_1955));
libro.agregar(new ViajeTemporal(2, "Buscar el Almanaque Deportivo", "Marty McFly", DestinoTemporal.HILL_VALLEY_2015));
libro.agregar(new ViajeTemporal(3, "Impedir la realidad alternativa de Biff", "Doc Brown", DestinoTemporal.REALIDAD_ALTERNATIVA));
libro.agregar(new ViajeTemporal(4, "Rescatar a Clara en el puente", "Doc Brown", DestinoTemporal.FAR_WEST_1885));
libro.agregar(new ViajeTemporal(5, "Restaurar la línea temporal original",
"Marty McFly", DestinoTemporal.LINEA_RESTAURADA));
System.out.println("Viajes en el tiempo:");
libro.paraCadaElemento(e -> System.out.println(e));
System.out.println("\nViajes a 1955:");
libro.filtrar(e -> e.getDestino().equals(DestinoTemporal.HILL_VALLEY_1955)).forEach(e -> System.out.println(e));
System.out.println("\nViajes que contienen 'almanaque':");
libro.filtrar(e -> e.getDescripcion().contains("almanaque")).forEach(e -> System.out.println(e));
System.out.println("\nViajes ordenados por ID:");
libro.ordenar((e1, e2) -> Integer.compare(e1.getId(), e2.getId()));
libro.paraCadaElemento(e -> System.out.println(e));
System.out.println("\nViajes ordenados por descripción:");
libro.ordenar((v1,v2) -> v1.getDescripcion().compareTo(v2.getDescripcion()));
libro.guardarEnArchivo("src/data/viajes.dat");
LibroDeViajes<ViajeTemporal> libroCargado = new LibroDeViajes<>();
libroCargado.cargarDesdeArchivo("src/data/viajes.dat");
System.out.println("\nViajes cargados desde archivo binario:");
libroCargado.paraCadaElemento(e -> System.out.println(e));
libro.guardarEnCSV("src/data/viajes.csv");
//libroCargado.cargarDesdeCSV("src/data/viajes.csv", /* Lambda */);
System.out.println("\nViajes cargados desde archivo CSV:");
libroCargado.paraCadaElemento(e -> System.out.println());
}catch(IOException | ClassNotFoundException ex){
System.err.println("Error: " + ex.getMessage());
}
    }

}
