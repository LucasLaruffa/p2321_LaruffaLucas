package models;

import java.io.Serializable;



public class ViajeTemporal implements Serializable {
    private int id;
    private String descripcion;
    private String viajero;
    private DestinoTemporal destino;

    public ViajeTemporal(int id, String descripcion, String viajero, DestinoTemporal destino) {
        this.id = id;
        this.descripcion = descripcion;
        this.viajero = viajero;
        this.destino = destino;
    }

    @Override
    public String toString() {
        return "ViajeTemporal{" + "id=" + id + ", descripcion=" + descripcion + ", viajero=" + viajero + ", destino=" + destino + '}';
    }
    
        public String toCSV(){
        StringBuilder sb = new StringBuilder();
        sb.append(id).append(",").append(descripcion).append(",").append(viajero).append(",").append(destino).append("\n");
        return sb.toString();
    }
    
        public static ViajeTemporal fromCSV(String productoCSV){
        productoCSV = productoCSV.substring(0, productoCSV.length()); 
        String[] datos = productoCSV.split(",");
        return new ViajeTemporal(Integer.parseInt(datos[0]), datos[1], datos[2], DestinoTemporal.valueOf(datos[3]));
    }
        
        public static String toHeaderCSV(){
            return "id,descripcion,viajero,destino";
}

    public int getId() {
        return id;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public String getViajero() {
        return viajero;
    }

    public DestinoTemporal getDestino() {
        return destino;
    }
        
        
    
    
    
    
    
    
}
