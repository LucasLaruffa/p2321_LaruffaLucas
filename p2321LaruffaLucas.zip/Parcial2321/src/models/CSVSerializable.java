package models;

import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;




public interface CSVSerializable<T> {
     void agregar(T item);

    boolean eliminar(T item);
    
    T obtener(int indice);
    
    List<T> filtrar(Predicate<? super T> criterio);
    
    void paraCadaElemento(Consumer<? super T> accion);
    
    void ordenar(Comparator<? super T> comp);
    
    
}
