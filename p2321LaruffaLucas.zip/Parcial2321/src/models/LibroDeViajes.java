package models;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import persistence.PersistenciaViajes;



public class LibroDeViajes<T extends ViajeTemporal> implements Serializable, CSVSerializable<T>, PersistenciaViajes {
    private List<T> elementos = new ArrayList<>();

    @Override
    public void agregar(T item) {
        Objects.requireNonNull(item, "ELEMENTO NULO");
        elementos.add(item);
    }

    @Override
    public boolean eliminar(T item) {
        Objects.requireNonNull(item, "ELEMENTO NULO");
        return elementos.remove(item);
    }

    @Override
    public T obtener(int indice) {
        validarIndice(indice);
        return elementos.get(indice);
    }
        private void validarIndice(int index) {
        if (index < 0 || index >= elementos.size()) {
            throw new IndexOutOfBoundsException("INDICE INVALIDO");
        }
    }

    @Override
    public List<T> filtrar(Predicate<? super T> criterio) {
        List<T> toReturn = new ArrayList<>();
        for (T e : elementos) {
            if (criterio.test(e)) {
                toReturn.add(e);
            }
        }
        return toReturn;
    }

    @Override
    public void paraCadaElemento(Consumer<? super T> accion) {
        elementos.forEach(e -> accion.accept(e));

    }

    @Override
    public void ordenar(Comparator<? super T> comp) {
        elementos.sort(comp);
    }

    @Override
    public void guardarEnCSV(String path) {
        try(BufferedWriter escritor = new BufferedWriter(new FileWriter(path))){
            
            escritor.write(T.toHeaderCSV());
            for(T e: elementos){
                escritor.write(e.toCSV());
            }
        }catch (IOException ex){
            System.out.println(ex.getMessage());
        
        }

    }

    @Override
    public void cargarDesdeCSV(String path, Function transformacion) {
        try(BufferedReader lector = new BufferedReader(new FileReader(path))){
            String linea;
            lector.readLine();
            while((linea = lector.readLine()) != null){
                elementos.add((T)transformacion.apply(linea));
            }}catch(IOException ex){
                System.out.println(ex.getMessage());
            }
        


    }

    @Override
    public void guardarEnArchivo(String path) throws IOException {
        try (ObjectOutputStream serializador = new ObjectOutputStream(new FileOutputStream(path))) {

            serializador.writeObject(elementos);
            
        } catch(IOException ex){
                System.out.println(ex.getMessage());
                }
    }

    @Override
    public void cargarDesdeArchivo(String path)throws ClassNotFoundException {
        
         try(ObjectInputStream deser = new ObjectInputStream(new FileInputStream(path))){
            
            elementos =(List<T>)deser.readObject();
            
            
            
        }catch(IOException | ClassNotFoundException ex){
                System.out.println(ex.getMessage());
                }
     
    }



    
    

}
